//How to translate a Simple Triangle
//Use WSAD to translate
//Hooman Salamat

//#include "Ogre.h"
#include "OgreApplicationContext.h"
#include "OgreInput.h"
#include "OgreRTShaderSystem.h"
#include "OgreTrays.h"
#include "Ball.h"
//#include "Paddle.cpp"
//#include "Gameplay.cpp"

#include <iostream>

using namespace Ogre;
using namespace OgreBites;

Ogre::Real m_Angle = 0.0;
Ogre::Vector3 paddleTranslate(0, 0, 0);
Ogre::Vector3 ballTranslate(0, 0, 0);
float upSpeed = 5.0;
float rightSpeed = 5.0;
int lives = 3;
int score = 0;


float paddleWidth = 3;
float paddleHeight = 1;
float leftBound = -8;
float rightBound = 8;

Ogre::SceneNode* PaddleNode;
OgreBites::TrayManager* mTrayMgr;

class PaddleFrameListener : public Ogre::FrameListener
{
private:
	Ogre::SceneNode* _node;
public:

	PaddleFrameListener(Ogre::SceneNode* node)
	{
		_node = node;
	}

	bool frameStarted(const Ogre::FrameEvent& evt)
	{
		_node->translate(paddleTranslate * evt.timeSinceLastFrame);
		paddleTranslate = Ogre::Vector3(0, 0, 0);

		if (_node->getPosition().x < leftBound)
		{
			_node->setPosition(-8, _node->getPosition().y, _node->getPosition().z);
		}
		else if (_node->getPosition().x + paddleWidth > rightBound)
		{
			_node->setPosition(8 - paddleWidth, _node->getPosition().y, _node->getPosition().z);
		}

		return true;
	}
};

class LabelsFrameListener : public Ogre::FrameListener
{
private:
	OgreBites::Label* _livesLabel;
	OgreBites::Label* _scoreLabel;
	OgreBites::Label* _timeLabel;


public:

	LabelsFrameListener(OgreBites::Label* livesLabel, OgreBites::Label* scoreLabel, OgreBites::Label* tpuLabel) //OgreBites::Label* tpuLabel
	{
		_livesLabel = livesLabel;
		_scoreLabel = scoreLabel;
		_timeLabel = tpuLabel;

	}

	bool frameStarted(const Ogre::FrameEvent& evt)
	{
		_livesLabel->setCaption("Lives: " + std::to_string(lives));
		_scoreLabel->setCaption("Score: " + std::to_string(score));
		_timeLabel->setCaption(std::to_string(evt.timeSinceLastFrame));
		//std::cout << evt.timeSinceLastFrame << std::endl;
		return true;

	}
};

class BallFrameListener : public Ogre::FrameListener
{
private:
	Ogre::SceneNode* _node;
public:

	BallFrameListener(Ogre::SceneNode* node)
	{
		_node = node;
	}

	bool frameStarted(const Ogre::FrameEvent& evt)
	{

		_node->translate(ballTranslate * evt.timeSinceLastFrame);
		ballTranslate = Ogre::Vector3(rightSpeed, upSpeed, 0);


		if (_node->getPosition().y > 5)
		{
			_node->setPosition(_node->getPosition().x, 4.9, _node->getPosition().z);

			upSpeed = -upSpeed;
		}

		else if (_node->getPosition().y < -6)
		{
			_node->setPosition(_node->getPosition().x, 4, _node->getPosition().z);
			upSpeed = -upSpeed ;
			lives--;
			
			//mScoreLabel->setCaption("Lives: " + std::to_string(lives));
			//OgreBites::Label* mLivesLabel = mTrayMgr->createLabel(TL_BOTTOM, "Lives2", "Lives2: " + std::to_string(lives), 100);
			

		}

		if (_node->getPosition().x + 1 > rightBound)
		{
			rightSpeed = -5;
		}
		if (_node->getPosition().x < leftBound)
		{
			rightSpeed = 5;
		}

		CollisionDetection(PaddleNode);

		return true;
	}

	void CollisionDetection(Ogre::SceneNode* _PaddleNode)
	{

		if (_node->getPosition().x < _PaddleNode->getPosition().x + paddleWidth&&
			_node->getPosition().x + 1 > _PaddleNode->getPosition().x &&
			_node->getPosition().y < _PaddleNode->getPosition().y + paddleHeight &&
			_node->getPosition().y + 1 > _PaddleNode->getPosition().y)
		{
			_node->setPosition(_node->getPosition().x, _PaddleNode->getPosition().y + paddleHeight + 0.1, _node->getPosition().z);
			upSpeed = 5;
			score++;
		}
	
	}
};



class PongAssignment
	: public ApplicationContext
	, public InputListener
{
private:
	SceneManager* scnMgr;
	Root* root;
public:
	PongAssignment();
	virtual ~PongAssignment() {}

	void setup();
	void createScene();
	void createCamera();
	bool keyPressed(const KeyboardEvent& evt);
	void createFrameListener();
	//Ogre::SceneNode* PaddleNode;
	Ogre::SceneNode* BallNode;

	OgreBites::TrayListener mTrayListener;
	//OgreBites::TrayManager myTrayManager;

	OgreBites::Label* mInfoLabel;
	OgreBites::Label* mTpuLabel;
	OgreBites::Label* mTpu;
	OgreBites::Label* mScoreLabel;
	OgreBites::Label* mLivesLabel;
};


PongAssignment::PongAssignment()
	: ApplicationContext("Pollock-PongAssignment")
{
}


void PongAssignment::setup()
{
	// do not forget to call the base first
	ApplicationContext::setup();
	addInputListener(this);

	// get a pointer to the already created root
	root = getRoot();
	scnMgr = root->createSceneManager();

	// register our scene with the RTSS
	RTShader::ShaderGenerator* shadergen = RTShader::ShaderGenerator::getSingletonPtr();
	shadergen->addSceneManager(scnMgr);
	createScene();
	createCamera();
	createFrameListener();
}

void PongAssignment::createScene()
{

	// -- tutorial section start --
	//! [turnlights]
	scnMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));
	//! [turnlights]

	//! [newlight]
	//
	Light* light1 = scnMgr->createLight("Light1");
	light1->setType(Ogre::Light::LT_POINT);
	// Set Light Color
	light1->setDiffuseColour(1.0f, 1.0f, 1.0f);
	// Set Light Reflective Color
	light1->setSpecularColour(1.0f, 0.0f, 0.0f);
	// Set Light (Range, Brightness, Fade Speed, Rapid Fade Speed)
	light1->setAttenuation(10, 0.5, 0.045, 0.0);

	//
	Entity* lightEnt = scnMgr->createEntity("LightEntity", "sphere.mesh");
	SceneNode* lightNode = scnMgr->createSceneNode("LightNode");
	lightNode->attachObject(lightEnt);
	lightNode->attachObject(light1);
	lightNode->setScale(0.01f, 0.01f, 0.01f);


	scnMgr->getRootSceneNode()->addChild(lightNode);
	//! [newlight]



	//! [lightpos]
	lightNode->setPosition(0, 4, 10);
	//! [lightpos]




	Ogre::ManualObject* PaddleObject = NULL;
	PaddleObject = scnMgr->createManualObject("Triangle");
	PaddleObject->setDynamic(false);
	PaddleObject->begin("FlatVertexColour",
		Ogre::RenderOperation::OT_TRIANGLE_LIST);
	PaddleObject->position(0, 0, 0);
	PaddleObject->colour(1, 0.5, 0);
	PaddleObject->position(paddleWidth, 0, 0);
	PaddleObject->colour(1, 0, 0);
	PaddleObject->position(paddleWidth, paddleHeight, 0);
	PaddleObject->colour(1, 0, 0);
	PaddleObject->position(0, paddleHeight, 0);
	PaddleObject->triangle(0, 1, 2);
	PaddleObject->triangle(0, 2, 3);

	PaddleObject->end();

	PaddleNode = scnMgr->getRootSceneNode()->
		createChildSceneNode("PaddleNode");
	PaddleNode->attachObject(PaddleObject);

	PaddleNode->translate(Ogre::Vector3(0, -5, 0));


	//Ball::Ball(scnMgr);

	Ogre::ManualObject* BallObject = NULL;
	BallObject = scnMgr->createManualObject("Triangle2");
	BallObject->setDynamic(false);
	BallObject->begin("FlatVertexColour",
		Ogre::RenderOperation::OT_TRIANGLE_LIST);
	BallObject->position(0, 0, 0);
	BallObject->colour(0, 0.5, 0);
	BallObject->position(1, 0, 0);
	BallObject->colour(0, 1, 0);
	BallObject->position(1, 1, 0);
	BallObject->colour(0, 1, 0);
	BallObject->position(0, 1, 0);
	BallObject->triangle(0, 1, 2);
	BallObject->triangle(0, 2, 3);

	BallObject->end();

	BallNode = scnMgr->getRootSceneNode()->
		createChildSceneNode("BallNode");
	BallNode->attachObject(BallObject);

	OgreBites::TrayManager* mTrayMgr = new OgreBites::TrayManager("InterfaceName", getRenderWindow());
	scnMgr->addRenderQueueListener(mOverlaySystem);
	addInputListener(mTrayMgr);


	//mTrayMgr->showLogo(TL_TOPRIGHT);
	mTrayMgr->showFrameStats(TL_BOTTOMLEFT);
	mTrayMgr->toggleAdvancedFrameStats();

	mTpuLabel = mTrayMgr->createLabel(TL_TOPRIGHT, "Time/Update", "Time/Update:", 150);
	mTpu = mTrayMgr->createLabel(TL_TOPRIGHT, "tpu", "0", 150);

	//mInfoLabel = mTrayMgr->createLabel(TL_TOP, "T1Info", "PollockPong", 350);
	mScoreLabel = mTrayMgr->createLabel(TL_TOPLEFT, "Score", "Score: " + std::to_string(score), 100);


	mLivesLabel = mTrayMgr->createLabel(TL_TOP, "Lives", "Lives: " + std::to_string(lives), 100);
	//mLivesLabel->setCaption("Score: " + std::to_string(score));


	// -- tutorial section end --


	//Ogre::Entity* ballEntity = scnMgr->createEntity(SceneManager::PrefabType::PT_SPHERE);
	//Ogre::SceneNode* ballNode = scnMgr->getRootSceneNode()->createChildSceneNode();
	//ballNode->setPosition(0, 0, 0);
	//ballNode->setScale(0.01f, 0.01f, 0.01f);
	//ballNode->attachObject(ballEntity);

}

void PongAssignment::createCamera()
{

	//! [camera]
	SceneNode* camNode = scnMgr->getRootSceneNode()->createChildSceneNode();

	// create the camera
	Camera* cam = scnMgr->createCamera("myCam");
	cam->setNearClipDistance(5); // specific to this sample
	cam->setAutoAspectRatio(true);
	camNode->attachObject(cam);
	camNode->setPosition(0, 0, 15);
	camNode->lookAt(Ogre::Vector3(0, 0, 0), Node::TS_WORLD);

	// and tell it to render into the main window
	getRenderWindow()->addViewport(cam);

	//! [camera]
}

bool PongAssignment::keyPressed(const KeyboardEvent& evt)
{
	switch (evt.keysym.sym)
	{
	case SDLK_ESCAPE:
		getRoot()->queueEndRendering();
		break;
	//case 'w':
	//	paddleTranslate = Ogre::Vector3(0, 10, 0);
	//	break;
	//case 's':
	//	paddleTranslate = Ogre::Vector3(0, -10, 0);
	//	break;
	case 'a':
		paddleTranslate = Ogre::Vector3(-10, 0, 0);
		break;
	case 'd':
		paddleTranslate = Ogre::Vector3(10, 0, 0);
		break;
	//case 'q':
	//	paddleTranslate = Ogre::Vector3(0, 0, -10);
	//	break;
	//case 'e':
	//	paddleTranslate = Ogre::Vector3(0, 0, 10);
	//	break;
	default:
		break;
	}
	return true;
}

void PongAssignment::createFrameListener()
{
	Ogre::FrameListener* FrameListener = new PaddleFrameListener(PaddleNode);
	mRoot->addFrameListener(FrameListener);
	
	Ogre::FrameListener* FrameListener2 = new BallFrameListener(BallNode);
	//FrameListener2->CollisionDetection(PaddleNode);
	mRoot->addFrameListener(FrameListener2);

	Ogre::FrameListener* FrameListener3 = new LabelsFrameListener(mLivesLabel, mScoreLabel, mTpu);
	mRoot->addFrameListener(FrameListener3);




}


int main(int argc, char** argv)
{
	try
	{
		PongAssignment app;
		app.initApp();
		app.getRoot()->startRendering();
		app.closeApp();
	}
	catch (const std::exception& e)
	{
		std::cerr << "Error occurred during execution: " << e.what() << '\n';
		return 1;
	}

	return 0;
}

//! [fullsource]
